#ifndef LIBFT_H
# define LIBFT_H

void	ft_putstr(char *s);
void	ft_swap(int *a, int *b);
int		ft_strlen(char *s);
int		ft_strcmp(char *s1, char *s2);
void	ft_putchar(char c);

#endif
