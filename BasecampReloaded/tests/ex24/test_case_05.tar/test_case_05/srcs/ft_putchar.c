#include "libft.h"

void	ft_putchar(char c)
{
	(void) c;
	return ;
}
