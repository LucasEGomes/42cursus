#include "libft.h"

int	ft_strlen(char *s)
{
	(void) s;
	return (0);
}
