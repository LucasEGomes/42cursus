#include "libft.h"

void	ft_swap(int *a, int *b)
{
	(void) a;
	(void) b;
	return ;
}
