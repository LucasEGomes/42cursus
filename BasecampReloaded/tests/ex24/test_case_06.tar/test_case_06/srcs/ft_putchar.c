#include "libft.h"

void	ft_putchar(char c)
{
	return ;
}
