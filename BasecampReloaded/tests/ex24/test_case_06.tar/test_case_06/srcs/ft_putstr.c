#include "libft.h"

void	ft_putstr(char *s)
{
	(void) s;
	return ;
}
