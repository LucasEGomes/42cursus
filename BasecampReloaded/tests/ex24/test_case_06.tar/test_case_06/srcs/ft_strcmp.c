#include "libft.h"

int	ft_strcmp(char *s1, char *s2)
{
	(void) s1;
	(void) s2;
	return (0);
}
